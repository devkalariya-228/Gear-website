document.addEventListener('DOMContentLoaded', function() {
    // Swiper initialization
    initializeSwiper('.new-arrivals-slider');
    initializeSwiper('.classics-slider');
    initializeSwiper('.sport-slider');

    // Add click event listeners to product links
    const productLinks = document.querySelectorAll('.product-link');
    productLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const shoeName = this.getAttribute('data-shoe-name');
            window.location.href = 'singleproduct.html?product=' + encodeURIComponent(shoeName);
        });
    });

    // Single product page functionality
    const urlParams = new URLSearchParams(window.location.search);
    const productName = urlParams.get('product');
    if (productName) {
        updateProductDetails(productName);
    }

    // Scroller functionality
    initializeScroller();
});

function initializeSwiper(selector) {
    new Swiper(selector, {
        slidesPerView: 1,
        spaceBetween: 10,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 3,
                spaceBetween: 40,
            },
            1024: {
                slidesPerView: 4,
                spaceBetween: 50,
            },
        },
    });
}

function updateProductDetails(productName) {
    document.getElementById('productName').textContent = productName;
    document.getElementById('productTitle').textContent = productName;
    
    // Set example data (replace with actual data fetching logic)
    document.getElementById('productPrice').textContent = '$99.99';
    document.getElementById('productMaterial').textContent = 'Leather';
    document.getElementById('productStyle').textContent = 'Casual';
    document.getElementById('mainImage').src = 'shoe1.jpg';
}

function initializeScroller() {
    const container = document.querySelector('.products-container');
    const leftBtn = document.querySelector('.scroll-btn.left');
    const rightBtn = document.querySelector('.scroll-btn.right');
    if (!container || !leftBtn || !rightBtn) return;

    const productWidth = 220; // 200px width + 20px margin
    const visibleProducts = 5;
    let scrollPosition = 0;

    leftBtn.addEventListener('click', () => {
        scrollPosition += productWidth * visibleProducts;
        if (scrollPosition > 0) scrollPosition = 0;
        container.style.transform = 'translateX(' + scrollPosition + 'px)';
    });

    rightBtn.addEventListener('click', () => {
        const maxScroll = (container.children.length - visibleProducts) * productWidth;
        scrollPosition -= productWidth * visibleProducts;
        if (Math.abs(scrollPosition) > maxScroll) scrollPosition = -maxScroll;
        container.style.transform = 'translateX(' + scrollPosition + 'px)';
    });
}

function changeMainImage(src) {
    const mainImage = document.getElementById('mainImage');
    if (mainImage) {
        mainImage.src = src;
        
        document.querySelectorAll('.thumbnail').forEach(thumb => {
            thumb.classList.toggle('active', thumb.src === src);
        });
    }
}

function selectSize(button) {
    document.querySelectorAll('.size-option').forEach(btn => {
        btn.classList.remove('selected');
    });
    button.classList.add('selected');
}

function selectColor(button) {
    document.querySelectorAll('.color-option').forEach(btn => {
        btn.classList.remove('selected');
    });
    button.classList.add('selected');
}